document.querySelector('form').addEventListener('submit', async function(e) {
    e.preventDefault();

    const form = e.target;
    const formData = new FormData(form);
    const url = form.action;

    if ([...formData.entries()].length === 0) {
        alert("Formularul este gol!");
        return;
    }

    try {
        let response = await fetch(url, {
            method: "POST",
            body: formData,
            headers: {
                'Accept': 'application/json'
            }
        });

        if (response.ok) {
            document.getElementById("success-message").style.display = "block";
            form.reset();
        } else {
            alert("A apărut o eroare! Încearcă din nou.");
        }
    } catch (error) {
        alert("A apărut o eroare de conexiune!");
    }
});
